
curl -s https://en.wikipedia.org/wiki/List_of_municipalities_of_Norway |
awk -v RS='<td style="text-align:left;"><a href="[^"]+" title="[^"]+">' 'NR>1{gsub(/<\/a>/,""); gsub(/<[^>]*>/, "", $0); print $1 "\t" $2 "\t" $3}' |
awk 'BEGIN{FS=OFS="\t"}{gsub(/&#39;/, "\047", $1); print $1, $2, $NF}' > /var/www/html/assigment/municipalities.coordinates.txt